﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace hybaniSipkami
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.Up:
                    panel1.Top -= 10;
                    break;
                case Keys.Down:
                    panel1.Top += 10;
                    break;
                case Keys.Left:
                    panel1.Left -= 10;
                    break;
                case Keys.Right:
                    panel1.Left += 10;
                    break;
            }
        }
    }
}
